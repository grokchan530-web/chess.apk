/* ===== Chess AI: iterative deepening alpha-beta with custom difficulty ===== */
(function (C) {
'use strict';
const { Position, P, N, B, R, Q, K, mFrom, mTo, mPromo, mFlags } = C;

const VAL = [0, 100, 320, 330, 500, 900, 0];
const PHASE = [0, 0, 1, 1, 2, 4, 0];
const INF = 31000, MATE = 30000, MATE_BOUND = 29000, MAX_PLY = 96;

// Piece-square tables (visual order: rank 8 first, from White's view)
const T = {
  1: [0,0,0,0,0,0,0,0, 50,50,50,50,50,50,50,50, 10,10,20,30,30,20,10,10, 5,5,10,25,25,10,5,5, 0,0,0,20,20,0,0,0, 5,-5,-10,0,0,-10,-5,5, 5,10,10,-20,-20,10,10,5, 0,0,0,0,0,0,0,0],
  2: [-50,-40,-30,-30,-30,-30,-40,-50, -40,-20,0,0,0,0,-20,-40, -30,0,10,15,15,10,0,-30, -30,5,15,20,20,15,5,-30, -30,0,15,20,20,15,0,-30, -30,5,10,15,15,10,5,-30, -40,-20,0,5,5,0,-20,-40, -50,-40,-30,-30,-30,-30,-40,-50],
  3: [-20,-10,-10,-10,-10,-10,-10,-20, -10,0,0,0,0,0,0,-10, -10,0,5,10,10,5,0,-10, -10,5,5,10,10,5,5,-10, -10,0,10,10,10,10,0,-10, -10,10,10,10,10,10,10,-10, -10,5,0,0,0,0,5,-10, -20,-10,-10,-10,-10,-10,-10,-20],
  4: [0,0,0,0,0,0,0,0, 5,10,10,10,10,10,10,5, -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5, 0,0,0,5,5,0,0,0],
  5: [-20,-10,-10,-5,-5,-10,-10,-20, -10,0,0,0,0,0,0,-10, -10,0,5,5,5,5,0,-10, -5,0,5,5,5,5,0,-5, 0,0,5,5,5,5,0,-5, -10,5,5,5,5,5,0,-10, -10,0,5,0,0,0,0,-10, -20,-10,-10,-5,-5,-10,-10,-20],
  6: [-30,-40,-40,-50,-50,-40,-40,-30, -30,-40,-40,-50,-50,-40,-40,-30, -30,-40,-40,-50,-50,-40,-40,-30, -30,-40,-40,-50,-50,-40,-40,-30, -20,-30,-30,-40,-40,-30,-30,-20, -10,-20,-20,-20,-20,-20,-20,-10, 20,20,0,0,0,0,20,20, 20,30,10,0,0,10,30,20],
};
const KEG = [-50,-40,-30,-20,-20,-30,-40,-50, -30,-20,-10,0,0,-10,-20,-30, -30,-10,20,30,30,20,-10,-30, -30,-10,30,40,40,30,-10,-30, -30,-10,30,40,40,30,-10,-30, -30,-10,20,30,30,20,-10,-30, -30,-30,0,0,0,0,-30,-30, -50,-30,-30,-30,-30,-30,-30,-50];

// PST[color][type][sq0x88]
const PST = [[], []];
const KEGT = [new Int16Array(128), new Int16Array(128)];
for (let t = 1; t <= 6; t++) {
  PST[0][t] = new Int16Array(128); PST[1][t] = new Int16Array(128);
  for (let r = 0; r < 8; r++) for (let f = 0; f < 8; f++) {
    const sq = r * 16 + f;
    PST[0][t][sq] = T[t][(7 - r) * 8 + f];
    PST[1][t][sq] = T[t][r * 8 + f];
    if (t === 6) { KEGT[0][sq] = KEG[(7 - r) * 8 + f]; KEGT[1][sq] = KEG[r * 8 + f]; }
  }
}
const PASSED = [0, 5, 10, 20, 35, 60, 100, 0];

// ---- Style weights (all neutral by default) ----
const STY_DEFAULT = { aggr: 0, centre: 1, pawnAdv: 0, rookAct: 0, kingSafety: 1, simplify: 0, material: 1, passed: 1 };
let STY = Object.assign({}, STY_DEFAULT);
let aggrWeight = 0;

function shield(b, ksq, color) { // own pawns directly in front of the king (2 ranks x 3 files)
  const dir = color === 0 ? 16 : -16, own = (color << 3) | P;
  let n = 0;
  for (let df = -1; df <= 1; df++) for (let k = 1; k <= 2; k++) {
    const s = ksq + dir * k + df;
    if (!(s & 0x88) && b[s] === own) n++;
  }
  return n;
}

function evaluate(pos) {
  const b = pos.board;
  let score = 0, phase = 0, kmg = 0, keg = 0;
  let wBish = 0, bBish = 0, matW = 0, matB = 0, cenW = 0, cenB = 0, advW = 0, advB = 0, rkW = 0, rkB = 0;
  const wPawns = new Int8Array(8), bPawns = new Int8Array(8);
  const bHigh = new Int8Array(8).fill(-1), wLow = new Int8Array(8).fill(8);
  const wRk = [], bRk = [];
  const wk = pos.king[0], bk = pos.king[1];
  let tropism = 0;
  for (let sq = 0; sq < 128; sq++) {
    if (sq & 0x88) { sq += 7; continue; }
    const p = b[sq];
    if (!p) continue;
    const t = p & 7, c = p >> 3, f = sq & 7, r = sq >> 4;
    if (t === K) {
      if (c) { kmg -= PST[1][6][sq]; keg -= KEGT[1][sq]; }
      else { kmg += PST[0][6][sq]; keg += KEGT[0][sq]; }
      continue;
    }
    phase += PHASE[t];
    const cen = 3.5 - Math.max(Math.abs(f - 3.5), Math.abs(r - 3.5));
    if (c === 0) {
      score += VAL[t] + PST[0][t][sq]; matW += VAL[t];
      if (t === P) { wPawns[f]++; if (r < wLow[f]) wLow[f] = r; if (r > 2) advW += r - 2; cenW += cen; }
      else if (t === B) { wBish++; cenW += cen; }
      else if (t === N) cenW += cen;
      else if (t === R) { wRk.push(sq); if (r === 6) rkW += 15; }
      if (aggrWeight && t !== P) { const d = Math.max(Math.abs(r - (bk >> 4)), Math.abs(f - (bk & 7))); tropism += (7 - d) * aggrWeight; }
    } else {
      score -= VAL[t] + PST[1][t][sq]; matB += VAL[t];
      if (t === P) { bPawns[f]++; if (r > bHigh[f]) bHigh[f] = r; if (r < 5) advB += 5 - r; cenB += cen; }
      else if (t === B) { bBish++; cenB += cen; }
      else if (t === N) cenB += cen;
      else if (t === R) { bRk.push(sq); if (r === 1) rkB += 15; }
      if (aggrWeight && t !== P) { const d = Math.max(Math.abs(r - (wk >> 4)), Math.abs(f - (wk & 7))); tropism -= (7 - d) * aggrWeight; }
    }
  }
  const ph = Math.min(24, phase);
  score += (kmg * ph + keg * (24 - ph)) / 24;
  if (wBish >= 2) score += 30;
  if (bBish >= 2) score -= 30;
  for (let f = 0; f < 8; f++) {
    if (wPawns[f] > 1) score -= 12 * (wPawns[f] - 1);
    if (bPawns[f] > 1) score += 12 * (bPawns[f] - 1);
  }
  const pm = STY.passed;
  for (let sq = 0; sq < 128; sq++) {
    if (sq & 0x88) { sq += 7; continue; }
    const p = b[sq];
    if ((p & 7) !== P) continue;
    const f = sq & 7, r = sq >> 4;
    if (p === P) {
      let passed = true;
      for (let g = Math.max(0, f - 1); g <= Math.min(7, f + 1); g++) if (bHigh[g] > r) { passed = false; break; }
      if (passed) score += PASSED[r] * pm;
    } else {
      let passed = true;
      for (let g = Math.max(0, f - 1); g <= Math.min(7, f + 1); g++) if (wLow[g] < r) { passed = false; break; }
      if (passed) score -= PASSED[7 - r] * pm;
    }
  }
  score += tropism;
  // ---- player-style terms ----
  if (STY.rookAct) {
    for (const sq of wRk) { const f = sq & 7; if (wPawns[f] === 0) rkW += bPawns[f] === 0 ? 14 : 7; }
    for (const sq of bRk) { const f = sq & 7; if (bPawns[f] === 0) rkB += wPawns[f] === 0 ? 14 : 7; }
    score += STY.rookAct * (rkW - rkB);
  }
  if (STY.centre !== 1) score += (STY.centre - 1) * 4 * (cenW - cenB);
  if (STY.pawnAdv) score += STY.pawnAdv * 3 * (advW - advB);
  if (STY.material !== 1) score += (STY.material - 1) * (matW - matB);
  if (STY.simplify) { let d = matW - matB; d = d > 300 ? 300 : d < -300 ? -300 : d; score += STY.simplify * d / 300 * (24 - ph) * 1.5; }
  if (STY.kingSafety) score += STY.kingSafety * 5 * (shield(b, wk, 0) - shield(b, bk, 1)) * ph / 24;
  return pos.turn ? -score : score;
}

// ---- Search state ----
const TT_BITS = 18, TT_SIZE = 1 << TT_BITS, TT_MASK = TT_SIZE - 1;
const ttKey = new Int32Array(TT_SIZE), ttMove = new Int32Array(TT_SIZE), ttScore = new Int16Array(TT_SIZE);
const ttDepth = new Int8Array(TT_SIZE), ttFlag = new Int8Array(TT_SIZE);
const bufs = [], scs = [];
for (let i = 0; i < MAX_PLY + 4; i++) { bufs.push(new Int32Array(256)); scs.push(new Int32Array(256)); }
const killers = new Int32Array((MAX_PLY + 4) * 2);
const hist = new Int32Array(2 * 128 * 128);
let nodes = 0, deadline = 0, stopped = false;

function scoreMoves(pos, buf, sc, n, ply, ttm) {
  const b = pos.board, us = pos.turn;
  for (let i = 0; i < n; i++) {
    const m = buf[i], to = mTo(m), fl = mFlags(m), from = mFrom(m);
    let s;
    if (m === ttm) s = 2000000;
    else if (fl & 1) {
      const victim = (fl & 2) ? P : (b[to] & 7);
      s = 1000000 + VAL[victim] * 10 - VAL[b[from] & 7] / 10 + (mPromo(m) ? 800 : 0);
    } else if (mPromo(m)) s = 900000 + VAL[mPromo(m)];
    else if (m === killers[ply * 2]) s = 800000;
    else if (m === killers[ply * 2 + 1]) s = 700000;
    else s = hist[(us << 14) | (from << 7) | to];
    sc[i] = s;
  }
}
function pickMove(buf, sc, n, i) {
  let bi = i, bs = sc[i];
  for (let j = i + 1; j < n; j++) if (sc[j] > bs) { bs = sc[j]; bi = j; }
  if (bi !== i) { const tm = buf[i]; buf[i] = buf[bi]; buf[bi] = tm; const ts = sc[i]; sc[i] = sc[bi]; sc[bi] = ts; }
}
function hasNonPawn(pos) {
  const b = pos.board, us = pos.turn;
  for (let s = 0; s < 128; s++) {
    if (s & 0x88) { s += 7; continue; }
    const p = b[s];
    if (p && (p >> 3) === us) { const t = p & 7; if (t >= N && t <= Q) return true; }
  }
  return false;
}

function quiesce(pos, alpha, beta, ply) {
  if ((++nodes & 2047) === 0 && Date.now() > deadline) stopped = true;
  if (stopped) return 0;
  const stand = evaluate(pos);
  if (ply >= MAX_PLY) return stand;
  if (stand >= beta) return stand;
  if (stand > alpha) alpha = stand;
  const buf = bufs[ply], sc = scs[ply];
  const n = pos.genMoves(buf, true);
  scoreMoves(pos, buf, sc, n, ply, 0);
  const us = pos.turn;
  for (let i = 0; i < n; i++) {
    pickMove(buf, sc, n, i);
    pos.make(buf[i]);
    if (pos.isAttacked(pos.king[us], us ^ 1)) { pos.unmake(); continue; }
    const s = -quiesce(pos, -beta, -alpha, ply + 1);
    pos.unmake();
    if (stopped) return 0;
    if (s >= beta) return s;
    if (s > alpha) alpha = s;
  }
  return alpha;
}

function negamax(pos, depth, alpha, beta, ply, nullOk) {
  if ((++nodes & 2047) === 0 && Date.now() > deadline) stopped = true;
  if (stopped) return 0;
  if (ply > 0) {
    if (pos.half >= 100 || pos.isRepetition()) return 0;
    if (ply >= MAX_PLY) return evaluate(pos);
    // mate distance pruning
    if (alpha < -MATE + ply) alpha = -MATE + ply;
    if (beta > MATE - ply - 1) beta = MATE - ply - 1;
    if (alpha >= beta) return alpha;
  }
  const us = pos.turn;
  const inChk = pos.inCheck();
  if (inChk) depth++;
  if (depth <= 0) return quiesce(pos, alpha, beta, ply);

  const idx = pos.hash & TT_MASK;
  let ttm = 0;
  const alpha0 = alpha;
  if (ttKey[idx] === pos.hash && ttFlag[idx]) {
    ttm = ttMove[idx];
    if (ply > 0 && ttDepth[idx] >= depth) {
      let s = ttScore[idx];
      if (s > MATE_BOUND) s -= ply; else if (s < -MATE_BOUND) s += ply;
      const fl = ttFlag[idx];
      if (fl === 1) return s;
      if (fl === 2 && s > alpha) alpha = s;
      else if (fl === 3 && s < beta) beta = s;
      if (alpha >= beta) return s;
    }
  }
  const pvNode = beta - alpha > 1;
  if (nullOk && !pvNode && !inChk && depth >= 3 && ply > 0 && hasNonPawn(pos)) {
    pos.makeNull();
    const s = -negamax(pos, depth - 3, -beta, -beta + 1, ply + 1, false);
    pos.unmakeNull();
    if (stopped) return 0;
    if (s >= beta) return s >= MATE_BOUND ? beta : s;
  }
  const buf = bufs[ply], sc = scs[ply];
  const n = pos.genMoves(buf, false);
  scoreMoves(pos, buf, sc, n, ply, ttm);
  let best = -INF, bestMove = 0, legal = 0;
  for (let i = 0; i < n; i++) {
    pickMove(buf, sc, n, i);
    const m = buf[i];
    pos.make(m);
    if (pos.isAttacked(pos.king[us], us ^ 1)) { pos.unmake(); continue; }
    const quiet = !(mFlags(m) & 1) && !mPromo(m);
    let s;
    if (legal === 0) s = -negamax(pos, depth - 1, -beta, -alpha, ply + 1, true);
    else {
      let red = 0;
      if (depth >= 3 && legal >= 4 && quiet && !inChk) { red = 1; if (legal >= 10 && depth >= 5) red = 2; }
      s = -negamax(pos, depth - 1 - red, -alpha - 1, -alpha, ply + 1, true);
      if (s > alpha && (red > 0 || s < beta)) s = -negamax(pos, depth - 1, -beta, -alpha, ply + 1, true);
    }
    pos.unmake();
    legal++;
    if (stopped) return 0;
    if (s > best) { best = s; bestMove = m; }
    if (s > alpha) {
      alpha = s;
      if (alpha >= beta) {
        if (quiet) {
          if (killers[ply * 2] !== m) { killers[ply * 2 + 1] = killers[ply * 2]; killers[ply * 2] = m; }
          const hi = (us << 14) | (mFrom(m) << 7) | mTo(m);
          hist[hi] = Math.min(600000, hist[hi] + depth * depth);
        }
        break;
      }
    }
  }
  if (legal === 0) return inChk ? -MATE + ply : 0;
  // store
  let st = best;
  if (st > MATE_BOUND) st += ply; else if (st < -MATE_BOUND) st -= ply;
  ttKey[idx] = pos.hash; ttMove[idx] = bestMove; ttScore[idx] = st; ttDepth[idx] = Math.min(depth, 100);
  ttFlag[idx] = best <= alpha0 ? 3 : (best >= beta ? 2 : 1);
  return best;
}

function rand01() { return Math.random(); }
function gauss() { return Math.sqrt(-2 * Math.log(1 - Math.random())) * Math.cos(2 * Math.PI * Math.random()); }

// ---- Opening lines (UCI). A line is used for whichever side it is the AI's turn to move. ----
const OP = {
  ruy:   ['e2e4','e7e5','g1f3','b8c6','f1b5','a7a6','b5a4','g8f6','e1g1','f8e7'],
  italian: ['e2e4','e7e5','g1f3','b8c6','f1c4','f8c5','c2c3','g8f6','d2d4','e5d4'],
  evans: ['e2e4','e7e5','g1f3','b8c6','f1c4','f8c5','b2b4','c5b4','c2c3','b4a5','d2d4','e5d4','e1g1'],
  kg:    ['e2e4','e7e5','f2f4','e5f4','g1f3','g7g5','h2h4','g5g4','f3e5'],
  berlin: ['e2e4','e7e5','g1f3','b8c6','f1b5','g8f6','e1g1','f6e4','d2d4','e4d6','b5c6','d7c6','d4e5','d6f5'],
  najdorf: ['e2e4','c7c5','g1f3','d7d6','d2d4','c5d4','f3d4','g8f6','b1c3','a7a6'],
  sveshnikov: ['e2e4','c7c5','g1f3','b8c6','d2d4','c5d4','f3d4','g8f6','b1c3','e7e5','d4b5','d7d6'],
  caro:  ['e2e4','c7c6','d2d4','d7d5','b1c3','d5e4','c3e4','c8f5'],
  french: ['e2e4','e7e6','d2d4','d7d5','b1c3','g8f6','c1g5','f8e7','e4e5','f6d7'],
  scand: ['e2e4','d7d5','e4d5','d8d5','b1c3','d5a5','d2d4','g8f6'],
  kid:   ['d2d4','g8f6','c2c4','g7g6','b1c3','f8g7','e2e4','d7d6','g1f3','e8g8'],
  grunfeld: ['d2d4','g8f6','c2c4','g7g6','b1c3','d7d5','c4d5','f6d5','e2e4','d5c3','b2c3','f8g7'],
  nimzo: ['d2d4','g8f6','c2c4','e7e6','b1c3','f8b4','e2e3','e8g8','f1d3','d7d5'],
  qgd:   ['d2d4','d7d5','c2c4','e7e6','b1c3','g8f6','c1g5','f8e7','e2e3','e8g8'],
  slav:  ['d2d4','d7d5','c2c4','c7c6','g1f3','g8f6','b1c3','d5c4'],
  catalan: ['d2d4','g8f6','c2c4','e7e6','g2g3','d7d5','f1g2','f8e7','g1f3','e8g8','e1g1'],
  qid:   ['d2d4','g8f6','c2c4','e7e6','g1f3','b7b6','g2g3','c8b7','f1g2','f8e7'],
  benoni: ['d2d4','g8f6','c2c4','c7c5','d4d5','e7e6','b1c3','e6d5','c4d5','d7d6'],
  reti:  ['g1f3','d7d5','c2c4','e7e6','g2g3','g8f6','f1g2','f8e7','e1g1','e8g8'],
  english: ['c2c4','e7e5','b1c3','g8f6','g1f3','b8c6','g2g3','d7d5','c4d5','f6d5'],
};

const STYLES = {
  standard: { name: 'Standard', desc: 'Balanced engine play. No particular style.', p: {}, lines: [] },
  carlsen: { name: 'Carlsen', desc: 'Patient and universal. Squeezes small edges and loves clean endgames.',
    p: { aggr: 5, centre: 1.05, pawnAdv: 0.1, rookAct: 0.8, simplify: 0.7, passed: 1.25 }, lines: [OP.reti, OP.english, OP.catalan, OP.berlin, OP.nimzo, OP.qgd, OP.ruy] },
  kasparov: { name: 'Kasparov', desc: 'Dynamic and aggressive. Takes the initiative and attacks the king.',
    p: { aggr: 65, centre: 1.2, pawnAdv: 0.8, rookAct: 1, kingSafety: 0.7, simplify: -0.2, material: 0.97 }, lines: [OP.najdorf, OP.kid, OP.grunfeld, OP.ruy, OP.nimzo] },
  fischer: { name: 'Fischer', desc: 'Sharp, precise and direct. Open positions and active pieces.',
    p: { aggr: 40, centre: 1.15, pawnAdv: 0.35, rookAct: 1, kingSafety: 0.9, simplify: 0.2, passed: 1.1 }, lines: [OP.ruy, OP.najdorf, OP.kid, OP.french] },
  tal: { name: 'Tal', desc: 'The magician. Sacrifices material for wild attacks and complications.',
    p: { aggr: 95, centre: 1.1, pawnAdv: 1, rookAct: 0.8, kingSafety: 0.25, simplify: -0.9, material: 0.72, passed: 0.9 }, lines: [OP.sveshnikov, OP.najdorf, OP.benoni, OP.evans] },
  karpov: { name: 'Karpov', desc: 'Boa constrictor. Quiet, safe and positional, slowly strangling you.',
    p: { aggr: 0, centre: 0.95, rookAct: 0.7, kingSafety: 1.5, simplify: 0.45, material: 1.04, passed: 1.3 }, lines: [OP.ruy, OP.caro, OP.qgd, OP.slav, OP.nimzo, OP.french] },
  capablanca: { name: 'Capablanca', desc: 'Clear and simple. Trades pieces when ahead and wins endgames.',
    p: { aggr: 0, pawnAdv: 0.05, rookAct: 0.9, simplify: 1.1, material: 1.02, passed: 1.2 }, lines: [OP.qgd, OP.slav, OP.ruy, OP.italian] },
  nakamura: { name: 'Nakamura', desc: 'Fast and practical. Tactical, creates problems and never gives up.',
    p: { aggr: 45, centre: 1.1, pawnAdv: 0.4, rookAct: 1, kingSafety: 0.7, simplify: -0.1, material: 0.92 }, lines: [OP.scand, OP.italian, OP.najdorf, OP.sveshnikov] },
  polgar: { name: 'Polgár', desc: 'Fearless attacker. Goes straight for the king.',
    p: { aggr: 80, centre: 1.1, pawnAdv: 0.6, rookAct: 1, kingSafety: 0.5, simplify: -0.4, material: 0.88 }, lines: [OP.najdorf, OP.sveshnikov, OP.grunfeld, OP.italian] },
  petrosian: { name: 'Petrosian', desc: 'Iron Tigran. Rock-solid defence, hard to attack.',
    p: { aggr: 0, centre: 0.9, rookAct: 0.5, kingSafety: 2, simplify: 0.4, material: 1.08, passed: 1.1 }, lines: [OP.qid, OP.caro, OP.french, OP.english, OP.reti] },
  morphy: { name: 'Morphy', desc: 'Romantic era. Rapid development and open attacking play.',
    p: { aggr: 60, centre: 1.35, pawnAdv: 0.3, rookAct: 0.8, kingSafety: 0.7, simplify: -0.3, material: 0.95, passed: 0.9 }, lines: [OP.italian, OP.evans, OP.kg] },
};

function setStyle(name) {
  const st = STYLES[name] || STYLES.standard;
  STY = Object.assign({}, STY_DEFAULT, st.p);
  aggrWeight = STY.aggr * 0.04;
}

function bookMove(pos, style) {
  const st = STYLES[style]; if (!st || !st.lines.length) return 0;
  const hist = [];
  for (let i = 0; i < pos.sp; i++) hist.push(pos.uci(pos.sMove[i]));
  if (hist.length > 16) return 0;
  const cands = [];
  for (const ln of st.lines) {
    if (ln.length <= hist.length) continue;
    let ok = true;
    for (let i = 0; i < hist.length; i++) if (ln[i] !== hist[i]) { ok = false; break; }
    if (ok) cands.push(ln[hist.length]);
  }
  if (!cands.length) return 0;
  const u = cands[Math.floor(rand01() * cands.length)];
  for (const m of pos.legalMoves()) if (pos.uci(m) === u) return m;
  return 0;
}

// ---- Elo -> engine behaviour. Approximate and self-calibrated, not an official rating. ----
function eloParams(elo) {
  elo = Math.max(300, Math.min(2800, elo));
  const t = (elo - 300) / 2500, o = {};
  if (elo < 1000) {                      // human-like beginner: looks one move ahead, misses things, sometimes plays randomly
    o.shallow = true; o.noQ = elo < 650;
    o.randMove = Math.max(0, 0.5 * Math.pow(1 - (elo - 300) / 1200, 1.2));
    o.noise = 250 * Math.pow(1 - t, 2.2);
    o.seeMate = Math.min(1, 0.6 + (elo - 300) / 700 * 0.4);
    o.depth = 1; o.time = 150; o.blunder = 0; o.random = 0;
    return o;
  }
  o.shallow = false;
  o.depth = elo < 1400 ? 2 : elo < 1700 ? 3 : elo < 2000 ? 4 : elo < 2300 ? 5 : elo < 2600 ? 6 : 8;
  o.time = Math.round(250 + Math.pow(t, 1.3) * 5000);
  o.blunder = Math.max(0, 22 * Math.pow(Math.max(0, 1 - (elo - 1000) / 1500), 1.6));
  o.random = Math.max(0, 60 * (1 - (elo - 1000) / 1400));
  return o;
}

function shallowPick(pos, root, P_) {
  if (rand01() < P_.randMove) return { move: root[Math.floor(rand01() * root.length)], score: 0, depth: 1, nodes: 0 };
  stopped = false; deadline = Date.now() + 250; nodes = 0;
  let bestM = root[0], bestS = -Infinity;
  for (const m of root) {
    pos.make(m);
    let s;
    if (pos.inCheck() && pos.legalMoves().length === 0) s = rand01() < P_.seeMate ? 20000 : 0;
    else s = P_.noQ ? -evaluate(pos) : -quiesce(pos, -INF, INF, 1);
    pos.unmake();
    s += gauss() * P_.noise;
    if (s > bestS) { bestS = s; bestM = m; }
  }
  return { move: bestM, score: bestS, depth: 1, nodes };
}

function search(pos, opts) {
  opts = Object.assign({ depth: 4, time: 1000, blunder: 0, random: 0, aggr: 0, style: 'standard', elo: 0, timeScale: 1, book: false }, opts || {});
  let P_ = null;
  if (opts.elo > 0) {
    P_ = eloParams(opts.elo);
    opts.depth = P_.depth; opts.time = Math.max(40, Math.round(P_.time * opts.timeScale));
    opts.blunder = P_.blunder; opts.random = P_.random;
  }
  setStyle(opts.style);
  if (!P_ && opts.aggr) { STY.aggr = Math.max(0, Math.min(100, opts.aggr)); aggrWeight = STY.aggr * 0.04; }
  const root = pos.legalMoves();
  if (root.length === 0) return { move: 0, score: 0, depth: 0, nodes: 0 };
  if (root.length === 1) return { move: root[0], score: 0, depth: 0, nodes: 0 };
  if (opts.book && opts.style !== 'standard' && (!P_ || opts.elo >= 700) && rand01() < 0.92) {
    const bm = bookMove(pos, opts.style);
    if (bm) return { move: bm, score: 0, depth: 0, nodes: 0, book: true };
  }
  if (P_ && P_.shallow) return shallowPick(pos, root, P_);
  ttKey.fill(0); ttFlag.fill(0); killers.fill(0); hist.fill(0);
  nodes = 0; stopped = false;
  deadline = Date.now() + Math.max(50, opts.time);
  let best = root[0], bestScore = 0, done = 0;
  const us = pos.turn;
  for (let d = 1; d <= opts.depth; d++) {
    let alpha = -INF, iterBest = 0, iterScore = -INF;
    const order = root.slice();
    const bi = order.indexOf(best);
    if (bi > 0) { order.splice(bi, 1); order.unshift(best); }
    for (let i = 0; i < order.length; i++) {
      const m = order[i];
      pos.make(m);
      let s;
      if (i === 0) s = -negamax(pos, d - 1, -INF, -alpha, 1, true);
      else {
        s = -negamax(pos, d - 1, -alpha - 1, -alpha, 1, true);
        if (!stopped && s > alpha) s = -negamax(pos, d - 1, -INF, -alpha, 1, true);
      }
      pos.unmake();
      if (stopped) break;
      if (s > iterScore) { iterScore = s; iterBest = m; }
      if (s > alpha) alpha = s;
    }
    if (stopped) { if (d === 1 && !iterBest) iterBest = best; else break; }
    best = iterBest || best; bestScore = iterScore; done = d;
    root.splice(0, root.length, ...order);
    if (Math.abs(bestScore) >= MATE_BOUND) break;
    if (Date.now() > deadline) break;
  }
  let chosen = best;
  const wantVariety = (opts.blunder > 0 || opts.random > 0) && Math.abs(bestScore) < MATE - 10;
  if (wantVariety) {
    // Score every root move at a modest depth, then pick a human-like move
    stopped = false; deadline = Date.now() + Math.max(300, opts.time);
    const dv = Math.max(1, Math.min(opts.depth - 1, 3));
    const list = [];
    for (const m of root) {
      pos.make(m);
      const s = -negamax(pos, dv - 1, -INF, INF, 1, true);
      pos.unmake();
      if (stopped) break;
      list.push({ m, s });
    }
    if (list.length > 1 && !stopped) {
      list.sort((a, b) => b.s - a.s);
      const top = list[0].s;
      if (rand01() * 100 < opts.blunder) {
        const pool = list.filter((x, i) => i > 0 && x.s <= top - 40 && x.s >= top - 450);
        if (pool.length) chosen = pool[Math.floor(rand01() * pool.length)].m;
        else chosen = list[Math.min(1, list.length - 1)].m;
      } else if (opts.random > 0) {
        const margin = opts.random * 1.5;
        const pool = list.filter(x => x.s >= top - margin);
        chosen = pool[Math.floor(rand01() * pool.length)].m;
      }
    }
  }
  return { move: chosen, score: bestScore, depth: done, nodes };
}

C.search = search;
C.evaluate = evaluate;
C.STYLES = STYLES; C.OP = OP; C.eloParams = eloParams; C.bookMove = bookMove; C.setStyle = setStyle;
})(Chess);
