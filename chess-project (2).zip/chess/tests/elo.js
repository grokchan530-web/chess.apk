// node tests/elo.js books            -> every opening line is legal
// node tests/elo.js pair A B GAMES   -> self-play between two strength levels (0 = uniformly random mover)
const fs = require('fs'), path = require('path');
const src = fs.readFileSync(path.join(__dirname, '../src/engine.js'), 'utf8') + '\n' + fs.readFileSync(path.join(__dirname, '../src/ai.js'), 'utf8') + '\nmodule.exports=Chess;';
const m = { exports: {} }; new Function('module', src)(m); const C = m.exports;
const mode = process.argv[2];

if (mode === 'books') {
  let bad = 0, n = 0;
  for (const [k, ln] of Object.entries(C.OP)) {
    const p = new C.Position(); n++;
    for (let i = 0; i < ln.length; i++) {
      const mv = p.legalMoves().find(x => p.uci(x) === ln[i]);
      if (!mv) { console.log('FAIL opening', k, 'illegal at ply', i + 1, ln[i]); bad++; break; }
      p.make(mv);
    }
  }
  console.log(bad ? 'BOOK FAILURES ' + bad : 'PASS all ' + n + ' opening lines are legal');
  // every style: bookMove returns a legal move at the start and its search returns legal moves in a middlegame
  const mid = 'r1bq1rk1/pp2bppp/2n1pn2/2pp4/3P4/2PBPN2/PP1N1PPP/R1BQ1RK1 w - - 0 9';
  for (const name of Object.keys(C.STYLES)) {
    const p = new C.Position();
    const r1 = C.search(p, { elo: 1500, style: name, book: true, timeScale: 0.05 });
    const q = new C.Position(); q.setFen(mid);
    const r2 = C.search(q, { elo: 1500, style: name, timeScale: 0.05 });
    const ok = p.legalMoves().includes(r1.move) && q.legalMoves().includes(r2.move);
    console.log((ok ? 'PASS ' : 'FAIL ') + 'style ' + name + '  opening: ' + p.uci(r1.move) + (r1.book ? ' (book)' : '') + '  middlegame: ' + q.uci(r2.move));
    if (!ok) bad++;
  }
  // styles really change evaluation
  const e = {}; for (const name of Object.keys(C.STYLES)) { C.setStyle(name); const q = new C.Position(); q.setFen('r1bq1rk1/pp3ppp/2n1pn2/2bp4/8/2NBPN2/PP3PPP/R1BQ1RK1 w - - 0 9'); e[name] = C.evaluate(q); }
  console.log('eval by style:', JSON.stringify(e)); C.setStyle('standard');
  process.exit(bad ? 1 : 0);
}

if (mode === 'pair') {
  const A = +process.argv[3], B = +process.argv[4], G = +process.argv[5] || 6, TS = +process.argv[6] || 0.12;
  const mat = p => { let s = 0; const V = [0, 100, 320, 330, 500, 900, 0]; for (let q = 0; q < 128; q++) { if (q & 0x88) { q += 7; continue; } const x = p.board[q]; if (x) s += ((x >> 3) ? -1 : 1) * V[x & 7]; } return s; };
  const pick = (p, lvl) => { if (lvl === 0) { const l = p.legalMoves(); return l[Math.floor(Math.random() * l.length)]; } return C.search(p, { elo: lvl, timeScale: TS }).move; };
  let scoreA = 0;
  for (let g = 0; g < G; g++) {
    const aWhite = g % 2 === 0, p = new C.Position(), seen = new Map(); let res = '1/2-1/2', ply = 0;
    while (ply < 200) {
      const st = p.status(); if (st.over) { res = st.result; break; }
      const k = p.repKey(); seen.set(k, (seen.get(k) || 0) + 1); if (seen.get(k) >= 3) break;
      if (ply === 140) { const d = mat(p); if (Math.abs(d) >= 400) { res = d > 0 ? '1-0' : '0-1'; break; } }
      const lvl = (p.turn === 0) === aWhite ? A : B;
      p.make(pick(p, lvl)); ply++;
    }
    const pts = res === '1/2-1/2' ? 0.5 : ((res === '1-0') === aWhite ? 1 : 0);
    scoreA += pts;
  }
  console.log(`Elo ${A} vs ${B}: first scored ${scoreA}/${G}`);
}
