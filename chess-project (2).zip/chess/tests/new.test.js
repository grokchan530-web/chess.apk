// Elo meter, styles, hanging-piece warning, background photo
const { chromium } = require('playwright');
const path = require('path');
const OUT = process.env.SHOTS || '/tmp/shots';
let fails = 0;
const ok = (n, c, x) => { console.log((c ? 'PASS ' : 'FAIL ') + n + (x !== undefined ? '  ' + x : '')); if (!c) fails++; };
(async () => {
  const browser = await chromium.launch();
  const errors = [];
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  const page = await ctx.newPage();
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  const url = 'file://' + path.resolve(__dirname, '../dist/chess.html');
  await page.goto(url); await page.waitForTimeout(500);
  const ev = (f, a) => page.evaluate(f, a);
  await ev(() => UI.closeAllDialogs());

  // ---- Elo meter + preset interplay ----
  await ev(() => { S.mode = 'ai'; openSheet(); });
  await page.waitForTimeout(400);
  ok('meter row rendered', await ev(() => !!document.querySelector('.row.meter .elobar i')));
  await page.getByRole('button', { name: 'Beginner', exact: true }).click(); await page.waitForTimeout(150);
  ok('Beginner preset = 400', await ev(() => S.aiElo === 400 && S.level === 'beginner'));
  ok('meter label says Absolute beginner', await ev(() => /Absolute beginner/.test(document.querySelector('.row.meter').textContent)), await ev(() => document.querySelector('.row.meter .val').textContent));
  await page.screenshot({ path: OUT + '/20-elo-beginner.png' });
  await ev(() => { const i = document.querySelector('.sbody input[type=range]'); i.value = 2000; i.dispatchEvent(new Event('input')); i.dispatchEvent(new Event('change')); });
  await page.waitForTimeout(200);
  ok('slider -> custom level, Elo 2000, meter live', await ev(() => S.aiElo === 2000 && S.level === 'custom' && /2000/.test(document.querySelector('.row.meter .val').textContent)));
  await page.getByRole('button', { name: 'Master', exact: true }).click(); await page.waitForTimeout(150);
  ok('Master preset = 2800', await ev(() => S.aiElo === 2800));
  await page.getByRole('button', { name: 'Tal', exact: true }).click(); await page.waitForTimeout(150);
  ok('style note shown', await ev(() => /sacrifices/i.test(document.querySelector('.sbody').textContent)));
  await page.screenshot({ path: OUT + '/21-style-tal.png' });
  await page.evaluate(() => { document.querySelector('.sbody').scrollTop = 0; });
  // advanced toggle reveals manual sliders and the meter becomes an estimate
  await page.locator('.row', { hasText: 'Advanced: tune the engine by hand' }).locator('.switch').click(); await page.waitForTimeout(150);
  ok('manual mode shows depth slider + estimate', await ev(() => /Search depth/.test(document.querySelector('.sbody').textContent) && /est\./.test(document.querySelector('.row.meter .val').textContent)));
  await page.locator('.row', { hasText: 'Advanced: tune the engine by hand' }).locator('.switch').click();
  await ev(() => closeSheet());

  // ---- AI as White with Tal style plays a book opening; plate shows style ----
  await ev(() => { setValue(DEFBY.level, 'club'); S.aiStyle = 'tal'; S.playerColor = 'black'; S.autoSave = false; newGame(); });
  await page.waitForFunction(() => G.moves.length >= 1 && !G.thinking, null, { timeout: 15000 });
  const first = await ev(() => G.sans[0]);
  ok('Tal (White) opens with a book move', ['e4', 'd4', 'c4'].includes(first), first);
  ok('plate shows Elo + style', await ev(() => /1200/.test(document.getElementById('plateTop').textContent) && /Tal/.test(document.getElementById('plateTop').textContent)), await ev(() => document.getElementById('plateTop').textContent));

  // ---- Beginner level really is weak: it hangs pieces ----
  // 40 beginner moves in a position where a queen can be grabbed for free: check how often it plays something else
  const grabs = await ev(async () => { const pos = new Chess.Position(); pos.setFen('rnb1kbnr/pppp1ppp/8/4p3/4P2q/5N2/PPPP1PPP/RNBQKB1R w KQkq - 0 1'); let n = 0; for (let i = 0; i < 60; i++) { const r = await AI.search(pos.fen ? 'rnb1kbnr/pppp1ppp/8/4p3/4P2q/5N2/PPPP1PPP/RNBQKB1R w KQkq - 0 1' : '', [], { elo: 400, timeScale: 0.2 }); if (pos.uci(r.move) === 'f3h4') n++; } return n; });
  console.log('Elo 400 takes a free queen in', grabs, 'of 60 tries');
  ok('Elo 400 is imperfect (misses it sometimes)', grabs < 60 && grabs > 5);

  // ---- hanging-piece warning ----
  await ev(() => { Object.assign(S, DEFAULTS); S.mode = '2p'; S.twoPView = 'none'; S.showThreats = true; newGame(true); G.startFen = '4k3/8/8/2q5/8/2N5/8/4K3 w - - 0 1'; G.pos.setFen(G.startFen); G.moves = []; G.sans = []; G.reps = [G.pos.repKey()]; G.legal = G.pos.legalMoves(); R.syncDisp(); updateThreats(); UI.update(); });
  await page.waitForTimeout(250);
  ok('threat warning flags attacked & undefended knight c3', await ev(() => R.threats.includes(Chess.nameSq('c3')) && R.threats.length === 1), await ev(() => JSON.stringify(R.threats.map(Chess.sqName))));
  await page.screenshot({ path: OUT + '/22-threat.png' });
  await ev(() => { S.showThreats = false; applyKeys(new Set(['showThreats'])); updateThreats(); });
  ok('threat warning off by default / switchable', await ev(() => R.threats.length === 0));

  // ---- background photo ----
  const makeImg = (w, h) => ev(async ([w, h]) => {
    const cv = document.createElement('canvas'); cv.width = w; cv.height = h; const g = cv.getContext('2d');
    const gr = g.createLinearGradient(0, 0, w, h); gr.addColorStop(0, '#ff3d81'); gr.addColorStop(0.5, '#ffd166'); gr.addColorStop(1, '#2ec4b6'); g.fillStyle = gr; g.fillRect(0, 0, w, h);
    g.fillStyle = '#fff'; g.font = 'bold ' + (h / 5) + 'px sans-serif'; g.textAlign = 'center'; g.fillText('PHOTO TEST', w / 2, h / 2); g.strokeStyle = '#000'; g.lineWidth = 8; g.strokeRect(20, 20, w - 40, h - 40);
    const blob = await new Promise(r => cv.toBlob(r, 'image/png'));
    const dt = new DataTransfer(); dt.items.add(new File([blob], 'photo.png', { type: 'image/png' }));
    window.__origSize = blob.size; const inp = document.getElementById('bgfile'); inp.files = dt.files; inp.dispatchEvent(new Event('change'));
    return blob.size;
  }, [w, h]);
  await ev(() => { Object.assign(S, DEFAULTS); applyKeys(new Set(Object.keys(DEFBY))); newGame(true); });
  const origSize = await makeImg(3000, 1500);
  await page.waitForFunction(() => UI.hasBg && S.bgType === 'image', null, { timeout: 8000 });
  await page.waitForTimeout(400);
  ok('photo picked -> background switches to Image automatically', await ev(() => S.bgType === 'image' && /blob:/.test(getComputedStyle(document.getElementById('bg')).backgroundImage)));
  const storedSize = await ev(async () => { const b = await BGDB.get(); return b ? b.size : -1; });
  ok('photo stored at ORIGINAL quality (not shrunk)', storedSize === origSize, storedSize + ' vs ' + origSize);
  await page.screenshot({ path: OUT + '/23-photo-fill.png' });
  await ev(() => { setValue(DEFBY.bgFit, 'contain'); });
  await page.waitForTimeout(250);
  ok('Fit-all mode shows the blurred backdrop layer', await ev(() => getComputedStyle(document.getElementById('bgback')).display === 'block'));
  await page.screenshot({ path: OUT + '/24-photo-fit.png' });
  await ev(() => { setValue(DEFBY.bgFit, 'cover'); setValue(DEFBY.bgZoom, 150); setValue(DEFBY.bgPosX, 20); });
  await page.waitForTimeout(250);
  ok('zoom + position applied', await ev(() => /scale\(1\.5\)/.test(document.getElementById('bg').style.transform) && /20%/.test(document.getElementById('bg').style.backgroundPosition)));
  // survives reload
  await page.reload(); await page.waitForTimeout(900);
  ok('photo still there after restart', await ev(() => UI.hasBg && S.bgType === 'image' && /blob:/.test(getComputedStyle(document.getElementById('bg')).backgroundImage)));
  await ev(() => UI.closeAllDialogs());
  await page.screenshot({ path: OUT + '/25-photo-after-reload.png' });
  // very large photo gets scaled to <= 4096 but stays sharp
  await makeImg(6000, 3000); await page.waitForTimeout(2500);
  const dims = await ev(async () => { const b = await BGDB.get(); const bm = await createImageBitmap(b); return bm.width + 'x' + bm.height; });
  ok('6000px photo reduced to 4096px (still high-res)', dims === '4096x2048', dims);
  // remove
  await ev(() => doAction('clearBg')); await page.waitForTimeout(300);
  ok('remove photo works', await ev(() => !UI.hasBg && S.bgType === 'gradient'));

  console.log('ERRORS:', errors.length ? errors : 'none');
  console.log(fails ? 'FAILURES: ' + fails : 'ALL NEW-FEATURE TESTS PASSED');
  await browser.close(); process.exit(fails || errors.length ? 1 : 0);
})().catch(e => { console.error('TEST CRASH', e); process.exit(2); });
