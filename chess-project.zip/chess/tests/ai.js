// Run: node tests/ai.js
const fs = require('fs'), path = require('path');
const src = fs.readFileSync(path.join(__dirname, '../src/engine.js'), 'utf8') + '\n' +
            fs.readFileSync(path.join(__dirname, '../src/ai.js'), 'utf8') + '\nmodule.exports = Chess;';
const m = { exports: {} }; new Function('module', src)(m); const Chess = m.exports;
let fail = 0;
function check(name, ok, extra) { console.log((ok ? 'PASS ' : 'FAIL ') + name + (extra ? ' ' + extra : '')); if (!ok) fail++; }

// 1. Mate in one (Qh5#-style): back-rank mate
{
  const pos = new Chess.Position(); pos.setFen('6k1/5ppp/8/8/8/8/8/R3K3 w Q - 0 1');
  const r = Chess.search(pos, { depth: 4, time: 2000 });
  check('back-rank mate found', pos.uci(r.move) === 'a1a8', pos.uci(r.move) + ' score ' + r.score);
}
// 2. Grabs a free queen
{
  const pos = new Chess.Position(); pos.setFen('rnb1kbnr/pppp1ppp/8/4p3/4P2q/5N2/PPPP1PPP/RNBQKB1R w KQkq - 0 1');
  const r = Chess.search(pos, { depth: 4, time: 2000 });
  check('plays Nxh4', pos.uci(r.move) === 'f3h4', pos.uci(r.move));
}
// 3. Avoids hanging queen / basic sanity, speed at depth 5
{
  const pos = new Chess.Position();
  const t0 = Date.now();
  const r = Chess.search(pos, { depth: 5, time: 8000 });
  console.log('start pos depth', r.depth, 'nodes', r.nodes, 'ms', Date.now() - t0, 'move', pos.uci(r.move));
  check('start pos returns a legal move', pos.legalMoves().includes(r.move));
}
// 4. Self-play: AI vs AI for a short game must stay legal and terminate cleanly
{
  const pos = new Chess.Position();
  let plies = 0, illegal = 0, st;
  while (plies < 120) {
    st = pos.status(); if (st.over) break;
    const r = Chess.search(pos, { depth: 3, time: 300, blunder: 10, random: 20, aggr: 30 });
    if (!pos.legalMoves().includes(r.move)) { illegal++; break; }
    pos.make(r.move); plies++;
  }
  check('self-play only legal moves', illegal === 0, 'plies=' + plies + ' end=' + JSON.stringify(st));
}
// 5. Difficulty levels: depth 1 vs depth 4 beat/lose? Just ensure depth1 is fast and legal
{
  const pos = new Chess.Position();
  const t0 = Date.now(); const r = Chess.search(pos, { depth: 1, time: 100 });
  check('depth1 fast', Date.now() - t0 < 200 && pos.legalMoves().includes(r.move), (Date.now() - t0) + 'ms');
}
// 6. Passed pawn eval sanity: white passed pawn on 6th should favour white
{
  const a = new Chess.Position(); a.setFen('4k3/8/4P3/8/8/8/8/4K3 w - - 0 1');
  const b = new Chess.Position(); b.setFen('4k3/4p3/8/8/8/8/8/4K3 w - - 0 1');
  check('passed pawn eval positive for white', Chess.evaluate(a) > 100, 'eval=' + Chess.evaluate(a));
  check('black pawn eval negative for white', Chess.evaluate(b) < 0, 'eval=' + Chess.evaluate(b));
}
console.log(fail ? 'FAILURES: ' + fail : 'ALL AI TESTS PASSED'); process.exit(fail ? 1 : 0);
